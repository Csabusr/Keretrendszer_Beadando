# Changelog

Sections for each relaese are:
_Added_,
_Changed_
_Deprecated_
_Removed_
_Fixed_
_Security_. Read [this](https://keepachangelog.com/en/1.0.0/) for more information about changelog.

## [Unreleased]

### Added

- Project Structure is set.
- Spring framework was added.
- Swagger was configured.
- Hibernate was added.
- ExceptionHandling example is added.

