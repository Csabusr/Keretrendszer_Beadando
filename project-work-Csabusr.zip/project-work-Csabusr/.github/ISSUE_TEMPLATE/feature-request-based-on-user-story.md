---
name: Feature Request based on User Story about: Suggest an idea for this project title: ''
labels: enhancement assignees: ''

---

As a <user>, I want to <do-something>, so that <benefit>

Acceptance Criteria

- List a objectives
- Measurable

Story Points: 1
