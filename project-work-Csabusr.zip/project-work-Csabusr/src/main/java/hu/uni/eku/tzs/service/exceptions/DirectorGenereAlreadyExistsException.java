package hu.uni.eku.tzs.service.exceptions;

public class DirectorGenereAlreadyExistsException extends Exception {
}
