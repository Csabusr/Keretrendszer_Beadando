package hu.uni.eku.tzs.service.exceptions;

public class MovieDirectorAlreadyExistsException extends Exception {
}
