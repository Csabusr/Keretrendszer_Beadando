package hu.uni.eku.tzs.service.exceptions;

public class MovieAlreadyExistsException extends Exception {
}
