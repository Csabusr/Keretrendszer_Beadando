package hu.uni.eku.tzs.service.exceptions;

public class DirectorAlreadyExistsException extends Exception {
}
