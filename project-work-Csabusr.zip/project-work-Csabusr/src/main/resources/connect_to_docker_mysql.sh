#!/usr/bin/env bash

USER=root
PASS=password
mysql -h 127.0.0.1 -u$USER -p$PASS
