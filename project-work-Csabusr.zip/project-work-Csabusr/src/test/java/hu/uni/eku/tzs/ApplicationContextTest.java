package hu.uni.eku.tzs;

import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@SpringJUnitConfig
public class ApplicationContextTest {
}
